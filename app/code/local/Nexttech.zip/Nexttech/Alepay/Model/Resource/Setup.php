<?php
class Nexttech_Alepay_Model_Resource_Setup extends Mage_Eav_Model_Entity_Setup {
}